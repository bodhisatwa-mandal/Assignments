const io = require('socket.io')(3000)

// Key of this object should be id of the socket
const users = {}

// All socket functions are invoked here
io.on('connection', socket => {
	
	socket.on('new-user', name => {
		users[socket.id] = name // All sockets have unique id, hence can be used as key

		// Inform all other users that a client has connected
		socket.broadcast.emit('user-connected', name)
	})

	socket.on('send-chat-message', message=> {	//Get message from client
		 // Send it to all other clients except the one from which message originates
		 // Create a new object passing message and client name
		socket.broadcast.emit('chat-message', {message: message, name:users[socket.id]})
	})

	// Inform all other users that a client has disconnected
	socket.on('disconnect', () =>{
		socket.broadcast.emit('user-disconnected', users[socket.id])
		delete users[socket.id]
	})

})