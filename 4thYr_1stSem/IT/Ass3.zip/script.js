const socket = io('http://localhost:3000')
const messageContainer = document.getElementById('message-container')
const messageForm = document.getElementById('send-container')
const messageInput = document.getElementById('message-input')

const name = prompt('Enter your name')
appendMessage('You have joined successfully')
socket.emit('new-user', name)

socket.on('chat-message', data => {
	appendMessage(`${data.name}: ${data.message}`) // Call function to append received messages
})

socket.on('user-connected', name => {
	appendMessage(`${name} has connected`) // Call function to append received messages
})

socket.on('user-disconnected', name => {
	appendMessage(`${name} has disconnected`) // Call function to append received messages
})

// Stop refreshing every time message is submitted
messageForm.addEventListener('submit', e => {
	e.preventDefault()
	const message = messageInput.value //Get actual message to send
	appendMessage(`You: ${message}`)
	socket.emit('send-chat-message', message)
	messageInput.value = '' //Empty out the message every time it is sent
})

// Function to append received messages
function appendMessage(message) {
	const messageElement = document.createElement('div')
	messageElement.innerText = message
	messageContainer.append(messageElement)
}